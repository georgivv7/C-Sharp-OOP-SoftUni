﻿namespace PlayersAndMonsters.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
