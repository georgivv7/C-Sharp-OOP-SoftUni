﻿public class RPG : Ammunition
{
    private const double weight = 17.1;
    public override double Weight => weight;
}