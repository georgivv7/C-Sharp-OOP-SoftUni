﻿public class AutomaticMachine : Ammunition
{
    public const double weight = 6.3;
    public override double Weight => weight;
}