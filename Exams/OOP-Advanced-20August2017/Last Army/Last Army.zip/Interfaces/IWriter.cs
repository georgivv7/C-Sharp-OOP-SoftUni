﻿public interface IWriter
{
    void AppendLine(string line);
    void WriteAll();
}