﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectonHierarchy
{
    public interface IRemove   
    {
        string Remove();    
    }
}
