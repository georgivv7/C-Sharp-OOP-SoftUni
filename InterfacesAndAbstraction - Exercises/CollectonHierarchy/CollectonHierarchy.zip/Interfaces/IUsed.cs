﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectonHierarchy
{
    public interface IUsed
    {
        int Used { get; }
    }
}
