﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CollectonHierarchy
{
    public interface IAdd
    {
        int Add(string item);   
    }
}
