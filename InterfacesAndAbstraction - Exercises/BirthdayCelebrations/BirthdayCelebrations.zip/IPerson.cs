﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations
{
    public interface IPerson
    {
        string Name { get; }
        int Age { get; }
        string Id { get; }
        string Birthdate { get; }
    }
}
