﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HotelReservation
{
    public enum SeasonsMultiply
    {
        Autumn = 1,
        Spring,
        Winter,
        Summer
    }
}
