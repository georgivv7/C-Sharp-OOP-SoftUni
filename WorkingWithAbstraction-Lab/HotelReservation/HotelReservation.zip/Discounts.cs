﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HotelReservation
{
    public enum Discounts
    {
        None,
        SecondVisit = 10,
        VIP = 20
    }
}
