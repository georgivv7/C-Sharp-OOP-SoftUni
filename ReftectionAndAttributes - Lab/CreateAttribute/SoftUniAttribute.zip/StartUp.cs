﻿using System;

[SoftUni("Dancho")]
class StartUp
{
    [SoftUni("Yovcho")]
    static void Main(string[] args)
    {
        Console.WriteLine("Hello World!");
    }
}
