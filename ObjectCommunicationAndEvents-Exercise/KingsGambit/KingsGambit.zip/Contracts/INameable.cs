﻿namespace KingsGambit.Contracts
{
    public interface INameable
    {
        string Name { get; }
    }
}
